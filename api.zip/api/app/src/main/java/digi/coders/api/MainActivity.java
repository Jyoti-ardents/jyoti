package digi.coders.api;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

import digi.coders.api.databinding.ActivityMainBinding;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding mainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_main);
        mainBinding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mainBinding.getRoot());


        List<PostModel> postModelsList=new ArrayList<>();
        mainBinding.postsRecycler.setLayoutManager(new LinearLayoutManager(MainActivity.this,LinearLayoutManager.VERTICAL,false));


        //ApiService apiService=RetrofitClientInstanse.getRetrofitClient().create(ApiService.class);

       RetrofitClientInstanse.getRetrofitClient().getAllPost().enqueue(new Callback<JsonArray>() {
           @Override
           public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {

               try {
                   if(response.isSuccessful()){

                       Log.d("ApiCalling","response successfull "+response.body().toString());

                       JsonArray jsonArray=response.body();
                      for(int i=0;i<jsonArray.size();i++){

                          JsonObject jsonObject=jsonArray.get(i).getAsJsonObject();

//                          String userId=jsonObject.get("userId").getAsString();
//                          String id=jsonObject.get("id").getAsString();
//                          String title=jsonObject.get("title").getAsString();
//                          String body=jsonObject.get("body").getAsString();
//
//
//                          PostModel postModel=new PostModel(userId,id,title,body);

                          PostModel postModel=new Gson().fromJson(jsonObject,PostModel.class);

                          postModelsList.add(postModel);
                      }
                      PostsRecyclerAdapter adapter=new PostsRecyclerAdapter(MainActivity.this,postModelsList);
                      mainBinding.postsRecycler.setAdapter(adapter);


                   }else {
                       Log.d("ApiCalling","response fail");
                   }
               }catch (Exception e){
                   Log.d("ApiCalling","Exception: "+e.getMessage());
               }



           }

           @Override
           public void onFailure(Call<JsonArray> call, Throwable t) {
               Log.d("ApiCalling","Throwable: "+t.getMessage());
           }
       });

    }
}