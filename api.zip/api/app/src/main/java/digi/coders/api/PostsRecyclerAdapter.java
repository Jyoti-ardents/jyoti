package digi.coders.api;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import digi.coders.api.databinding.PostsLayBinding;

public class PostsRecyclerAdapter extends RecyclerView.Adapter<PostsRecyclerAdapter.ViewHolder> {
    @NonNull
    Context context;
    List<PostModel> postModelslist;

    public PostsRecyclerAdapter(@NonNull Context context, List<PostModel> postModelslist) {
        this.context = context;
        this.postModelslist = postModelslist;
    }

    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater=LayoutInflater.from(context);
        PostsLayBinding postsLayBinding=PostsLayBinding.inflate(layoutInflater,parent,false);
        ViewHolder viewHolder=new ViewHolder(postsLayBinding);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
       PostModel postModel=postModelslist.get(position);
       holder.postsLayBinding.pid.setText("id :"+postModel.getId());
       holder.postsLayBinding.userid.setText("Userid :"+postModel.getUserId());
       holder.postsLayBinding.title.setText("Title :"+postModel.getTitle());
       holder.postsLayBinding.body.setText("Body :"+postModel.getBody());

    }

    @Override
    public int getItemCount() {
        return postModelslist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        PostsLayBinding postsLayBinding;
//        public ViewHolder(@NonNull View itemView) {
//            super(itemView);
//        }
        public ViewHolder(@NonNull PostsLayBinding postsLayBinding){
            super(postsLayBinding.getRoot());
            this.postsLayBinding=postsLayBinding;
        }
    }
}
